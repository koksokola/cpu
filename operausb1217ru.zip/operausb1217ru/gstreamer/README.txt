Opera uses the GStreamer multimedia framework and the GLib utility
library. GStreamer and GLib are covered by the GNU LGPL license.
A copy of the license can be found in LGPL.txt in this directory.

This directory contains binaries of GStreamer libraries and plugins
for platforms that do not natively include them. The source code can
be downloaded from http://sourcecode.opera.com/gstreamer/
