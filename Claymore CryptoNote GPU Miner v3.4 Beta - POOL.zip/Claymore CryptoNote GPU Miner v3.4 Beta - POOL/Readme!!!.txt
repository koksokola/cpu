Claymore's XMR/QCN/FCN/BCN GPU Miner.
=========================

This is POOL version.

Catalyst 13.12 is required for best performance and compatibility.

Set "GPU_MAX_ALLOC_PERCENT" environment variable as "100".

For multi-GPU systems, set Virtual Memory size in Windows at least 16 GB:
"Computer Properties / Advanced System Settings / Performance / Advanced / Virtual Memory".

This miner is free-to-use, however, current developer fee is 5%, miner mines 19 rounds for you and 1 round for developer.

This version is for recent AMD videocards only: 7xxx and 2xx, perhaps it also works on 6xxx. No nVidia support. 

This version is for Windows x64 only. No Windows x32 support. No Linux support. 

This version has no GPU temperature and overclocking management.



COMMAND LINE OPTIONS:

-o 	pool address. Both HTTP and Stratum protocol are supported. You can specify several "-o" parameters to use several pools, or use "pools.txt" file, or use both. 
	First pool specified via "-o" option is main pool: miner will switch to main pool every 30 minutes.

-u 	your wallet address.

-p 	password, use "x" as password.

-di 	GPU indexes, default is all available GPUs. For example, if you have four GPUs "-di 02" will enable only first and third GPUs.

-wd 	watchdog option. Use "-wd 1" to enable watchdog, miner will be closed if any thread is not responding for 1 minute, so you can restart it from some script if 
some GPU does not respond.

-ee 	close miner if no more pools are available in the list. By default, miner tries all pools one by one, after last pool it tries first pool again and so on. 
Use "-ee 1" to close miner when it tried all pools, so you can restart it from some script and do some additional actions related to internet connectins if necessary.

-dbg	debug log and messages. "-dbg 0" (default) - create log file but don't show debug messages. 
	"-dbg 1" - create log file and show debug messages. "-dbg -1" - no log file and no debug messages.



SAMPLE USAGE

NsGpuCNMiner.exe -o stratum+tcp://monero.crypto-pool.fr:6666 -u 449TGay4WWJPwsXrWZfkMoPtDbJp8xoSzFuyjRt3iaM4bRHdzw4qoDu26FdcGx67BMDS1r2bnp7f5hF6xdPWWrD3Q3Wf7G6 -p x

Do not forget to specify your wallet address!



FAIL-OVER

Use "-o" option or "pools.txt" file to specify several pools. Every pool has 3 connection attempts. "pools.txt" file has text format, one address per line. 
If the first character of a line is ";" this line will be ignored. 
After pool address you can also specify login and password, use space as separator, for example:

mro.pool.minergate.com:5556 yourmail@gmail.com !

or

stratum+tcp://monero.crypto-pool.fr:6666 449TGay4WWJPwsXrWZfkMoPtDbJp8xoSzFuyjRt3iaM4bRHdzw4qoDu26FdcGx67BMDS1r2bnp7f5hF6xdPWWrD3Q3Wf7G6 x

If login or password are not specified, "-u" and "-p" parameters will be used.



PERFORMANCE

About 600 h/s on stock 290X.
About 450 h/s on stock 280X.
About 300 h/s on stock 270X.



TROUBLESHOOTING

1. Install Catalyst v13.12.
2. Disable overclocking.
3. Set GPU_MAX_ALLOC_PERCENT 100.
4. Set Virtual Memory 16 GB.
5. Reboot computer.



